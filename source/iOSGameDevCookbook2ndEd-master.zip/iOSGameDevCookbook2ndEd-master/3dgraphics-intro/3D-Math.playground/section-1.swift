// Playground - noun: a place where people can play

import UIKit
import GLKit

var vector : GLKVector3 = GLKVector3Make(1,2)
