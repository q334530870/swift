//
//  GameObject.swift
//  Pausing
//
//  Created by Jon Manning on 13/01/2015.
//  Copyright (c) 2015 Secret Lab. All rights reserved.
//

import UIKit

class GameObject: NSObject {
    
    var canPause : Bool = true
    
    func update(deltaTime: Float) {
        
    }
    
}
