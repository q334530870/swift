//
//  Bridging.h
//  CustomGestureRecognizer
//
//  Created by Jon Manning on 16/01/2015.
//  Copyright (c) 2015 Secret Lab. All rights reserved.
//

// BEGIN import_header
#import <UIKit/UIGestureRecognizerSubclass.h>
// END import_header