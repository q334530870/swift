import PackageDescription

let package = Package(
    name: "Vapor",
    dependencies: [
    ]
)