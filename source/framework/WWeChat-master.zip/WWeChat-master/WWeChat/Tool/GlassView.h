//
//  GlassView.h
//  WWeChat
//
//  Created by wordoor－z on 16/2/17.
//  Copyright © 2016年 wzx. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GlassView : UIView

- (void)showToView:(UIView *)view;

- (void)hide;
@end
