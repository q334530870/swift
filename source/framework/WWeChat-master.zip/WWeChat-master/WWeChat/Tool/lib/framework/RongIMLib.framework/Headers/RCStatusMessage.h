/**
 * Copyright (c) 2014-2015, RongCloud.
 * All rights reserved.
 *
 * All the contents are the copyright of RongCloud Network Technology Co.Ltd.
 * Unless otherwise credited. http://rongcloud.cn
 *
 */

//  RCStatusMessage.h
//  Created by Heq.Shinoda on 14-6-13.

#import "RCMessageContent.h"

@interface RCStatusMessage : RCMessageContent

@end
