//
//  ChatModel.m
//  WWeChat
//
//  Created by wordoor－z on 16/1/29.
//  Copyright © 2016年 wzx. All rights reserved.
//

#import "ChatModel.h"

@implementation ChatModel



@end
