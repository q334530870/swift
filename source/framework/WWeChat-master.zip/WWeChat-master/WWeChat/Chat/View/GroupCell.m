//
//  MessageCell.m
//  WWeChat
//
//  Created by wordoor－z on 16/3/4.
//  Copyright © 2016年 wzx. All rights reserved.
//

#import "GroupCell.h"

@implementation GroupCell

@end
