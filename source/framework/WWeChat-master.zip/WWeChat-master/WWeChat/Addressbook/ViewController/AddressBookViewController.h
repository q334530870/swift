//
//  AddressBookViewController.h
//  WWeChat
//
//  Created by wordoor－z on 16/1/28.
//  Copyright © 2016年 wzx. All rights reserved.
//

#import "BaseViewController.h"

@interface AddressBookViewController : BaseViewController

@end
