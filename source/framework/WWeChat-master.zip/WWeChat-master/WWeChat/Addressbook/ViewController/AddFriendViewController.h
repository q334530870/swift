//
//  AddFriendViewController.h
//  WWeChat
//
//  Created by wordoor－z on 16/2/17.
//  Copyright © 2016年 wzx. All rights reserved.
//

#import "BaseViewController.h"

@interface AddFriendViewController : BaseViewController

@end
