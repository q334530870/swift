//
//  SearchFriendViewController.h
//  WWeChat
//
//  Created by wordoor－z on 16/3/3.
//  Copyright © 2016年 wzx. All rights reserved.
//

#import "BaseViewController.h"

@interface SearchFriendViewController : BaseViewController

@end
