//
//  QuanModel.m
//  WWeChat
//
//  Created by wordoor－z on 16/3/17.
//  Copyright © 2016年 wzx. All rights reserved.
//

#import "QuanModel.h"

@implementation QuanModel

@end
