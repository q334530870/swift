//
//  QuanViewController.h
//  WWeChat
//
//  Created by 王子轩 on 16/2/4.
//  Copyright © 2016年 wzx. All rights reserved.
//

#import "BaseViewController.h"

@interface QuanViewController : BaseViewController

@end
