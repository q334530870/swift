//
//  PersonViewController.h
//  WWeChat
//
//  Created by 王子轩 on 16/2/3.
//  Copyright © 2016年 wzx. All rights reserved.
//

#import "BaseViewController.h"

@interface PersonViewController : BaseViewController

@end
