//
//  PersonModel.m
//  WWeChat
//
//  Created by wordoor－z on 16/1/29.
//  Copyright © 2016年 wzx. All rights reserved.
//

#import "PersonModel.h"

@implementation PersonModel

@end
