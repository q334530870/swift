//
//  Constants.m
//  Chameleon
//
//  Created by Vicc Alexander on 6/4/15.
//  Copyright (c) 2015 Vicc Alexander. All rights reserved.
//

#import "ChameleonConstants.h"

const UIStatusBarStyle UIStatusBarStyleContrast = 100;

@implementation ChameleonConstants

@end
