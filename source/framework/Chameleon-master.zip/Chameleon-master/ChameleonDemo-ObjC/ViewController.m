//
//  ViewController.m
//  ChameleonDemo-Objc
//
//  Created by Vicc Alexander on 11/26/15.
//  Copyright © 2015 Vicc Alexander. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    
    //Super
    [super viewDidLoad];
    
    //Set View Background
    self.view.backgroundColor = FlatYellow;
}

- (void)didReceiveMemoryWarning {
    
    //Super
    [super didReceiveMemoryWarning];
}

@end
