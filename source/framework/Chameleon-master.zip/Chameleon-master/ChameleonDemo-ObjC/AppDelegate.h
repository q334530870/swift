//
//  AppDelegate.h
//  ChameleonDemo-Objc
//
//  Created by Vicc Alexander on 11/26/15.
//  Copyright © 2015 Vicc Alexander. All rights reserved.
//

#import <UIKit/UIKit.h>
@import Chameleon;

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

